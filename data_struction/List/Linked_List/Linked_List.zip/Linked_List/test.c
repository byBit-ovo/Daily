#include "Link_List.h"
void test()
{
	Node* plist = NULL;
	Push_back(&plist, 520);
	Print_List(plist);
}
int main()
{
	test();
	
	return 0;
}