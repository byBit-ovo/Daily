#pragma once
#include <stdio.h>
typedef int DataType;
typedef struct link
{
	DataType data;
	struct link* next;
}Node;

void Push_back(Node** phead, DataType x);
void Print_List(Node* phead)
{
	while (phead->next != NULL)
	{
		printf("%d->", phead->data);
	}
	printf("NULL");
}
