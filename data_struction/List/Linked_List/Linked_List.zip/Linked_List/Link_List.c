#include "Link_List.h"

void Push_back(Node** pphead, DataType x)
{
	Node* newnode = (Node*)malloc(sizeof(Node));
	newnode->data = x;
	newnode->next = NULL;
	if (*pphead == NULL)
	{
		*pphead = newnode;
		return;
	}

	Node* temp = *pphead;
	while (temp->next != NULL)
	{
		temp = temp->next;
	}
	//temp�Ѿ�ָ��β�ڵ�
	temp->next = newnode;

}