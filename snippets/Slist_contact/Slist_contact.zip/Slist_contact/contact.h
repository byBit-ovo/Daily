#define _CRT_SECURE_NO_WARNINGS 
#pragma once
#include <stdio.h>
typedef struct info
{
	char name[20];
	char phone[12];
	char address[30];
}Person;

typedef Person DataType;
typedef struct list
{
	DataType x;
	struct list* next;
}Slist;

void Push_back(Slist* phead);
void Pop_back(Slist* phead);
void Show(Slist* phead);
void Search_by_name(Slist* phead, char name[20]);
