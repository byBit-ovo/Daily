#define _CRT_SECURE_NO_WARNINGS 
#include "contact.h"
Slist* Buy_node(DataType x)
{
	Slist* newnode = (Slist*)malloc(sizeof(Slist));
	newnode->next = NULL;
	newnode->x = x;
	return newnode;
}

void Push_back(Slist* phead)
{
	Person person;
	printf("������ϵ�ˣ�\n");
	printf("������������\n");
	scanf("%s", person.name);
	printf("������绰��\n");
	scanf("%s", person.phone);
	printf("�������ַ��\n");
	scanf("%s", person.address);
	Slist* newnode = Buy_node(person);
	Slist* pcur = phead;
	while (pcur->next != NULL)
	{
		pcur = pcur->next;
	}
	pcur->next = newnode;
}
void show(Slist* phead)
{
	Slist* pcur = phead->next;
	while (pcur!= NULL)
	{
		printf("%s\t%s\t%s\n", pcur->x.name, pcur->x.phone, pcur->x.address);
		pcur = pcur->next;
	}
}
